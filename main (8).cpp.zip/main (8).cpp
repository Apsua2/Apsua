#include <iostream>
#include <vector>
#include "test.h"

std::vector<int> create_vec(int amount) {
    std::vector<int> expect_vec;
    int num = 1;
    for (int i = 0; i < amount - 1; ++i) {
        expect_vec.push_back(num);
        num *= 2;
    }
    
    expect_vec.push_back(22);
    for(auto i: expect_vec) {
        std::cout << i << ' ';
    }
    return expect_vec;
}

int main() {
    test::test_some_func(create_vec);
    return 0;
}
